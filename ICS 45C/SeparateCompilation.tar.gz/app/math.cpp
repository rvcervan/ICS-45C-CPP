// math.cpp
//
// ICS 45C Winter 2019
// Code Example
//
// Implementation of the cube function.  No surprises here.

#include "math.hpp"


int cube(int n)
{
    return n * n * n;
}

